
(function(){
  const btn = document.getElementById('navToggle');
  const menu = document.getElementById('menu');
  if(btn && menu){
    btn.addEventListener('click', ()=> menu.classList.toggle('open'));
  }
  function pad(n){return n<10?'0'+n:n}
  document.querySelectorAll('.countdown').forEach(el=>{
    const deadline = el.getAttribute('data-deadline');
    if(!deadline) return;
    function tick(){
      const end = new Date(deadline).getTime();
      const now = Date.now();
      let diff = Math.max(0, end - now);
      const d = Math.floor(diff / (1000*60*60*24)); diff -= d*86400000;
      const h = Math.floor(diff / (1000*60*60)); diff -= h*3600000;
      const m = Math.floor(diff / (1000*60)); diff -= m*60000;
      const s = Math.floor(diff / 1000);
      el.textContent = `Starts in ${d}d ${pad(h)}h:${pad(m)}m:${pad(s)}s`;
      if(end > now) requestAnimationFrame(()=>setTimeout(tick, 1000));
      else el.textContent = 'LIVE / COMPLETED';
    }
    tick();
  });
})();
